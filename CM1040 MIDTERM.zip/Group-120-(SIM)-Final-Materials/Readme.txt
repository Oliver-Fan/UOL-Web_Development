This is submitted for CM1040 Web Development: 
Coursework 1.1 A single bundled team assignment submission [001] 

Submitted by: 
Chow Su Yee (Group leader) on behalf of Group 120 (SIM)

Group members:
1. Chow Su Yee (Group leader)
2. Asikfarieth Mohamed
3. Hao Fan
4. Zhoutongyue Li
5. Xinjie Li

——————————————————————————————————————————————————————————————

URL: 
https://hub.coursera-apps.org/connect/sharedmzkodrjv

——————————————————————————————————————————————————————————————

Folder content:
1. Readme.txt (This file)

2. Part 1 Design Specification
- Research and write up document
- Wireframes images

3. Part 2 Creating the HTML
- HTML Markup
- HTML source code files

4. Part 3 Adding Style
- CSS Part 3 Markup
- HTML and CSS source code files

5. Part 4 Adding Layout
- CSS Part 4 Markup
- Final HTML and CSS source code files

——————————————————————————————————————————————————————————————

About the theme park website:
The theme of the theme park is based on Nestle, 
world's largest food and beverage brand. 
The attractions are based on Nestle's classic brands, 
where there is something for people of all ages, be it young or old.  

——————————————————————————————————————————————————————————————

Distribution of workload:
As there are 5 members in this group, we decided to create 5 web pages and be responsible for 1 page each. The HTML and corresponding CSS code is written by the same person. You may find the credits at the top of each HTML file, commented. 

——————————————————————————————————————————————————————————————

Workflow: 
We would meet up virtually once every week to discuss about our web site. Once we are happy with our code for each of our page, the group leader will take all the codes from the members and compile them into 1 finalised folder, to ensure consistency. Hence, workload is equally distributed among the 5 members.

——————————————————————————————————————————————————————————————

- End -