/* -Final Game Project

- for the p5.Sound library look here https://p5js.org/reference/#/libraries/p5.sound
- for finding cool sounds perhaps look here
https://freesound.org/
https://http://moyimusic.com/
*/

/*     Code Explaining for Extensions:  */

/*For my project, I choosed the "Add Aound" and the "Create Platforms" as my two extensions. 

For "Add Sound", I think it's a great idea to add music to the game because it adds to the fun of the game and the right game soundtrack gives the player a better gaming experience. But the difficulty with this approach is that, first, it is necessary to take the time to choose the right soundtrack from a large amount of music material (such as background music and the action soundtrack of the characters) in order to achieve the desired game effect. Second, you need to pair it to a relative character action and ensure that each insertion does not conflict with each other or cause the game to run incorrectly. Although there was a problem during the test where the music file did not match the character's movements, resulting in an abnormal playback, it was eventually fixed by me. Through this project, I learned how to collect and download sound material online, and learned how to insert it into the program and fix errors.


For "Create Platforms", I think compared to the simple scoring mechanism, the increased platform enhancesthe game's playability. The difficulty with this process is setting the function of the platform. I chose to place each platform above the canyon. Usually, when facing the platform, the player will choose to jump from a distance on the platform or think that jumping below the platform will be hit by the platform will cause the game to fail, in order to avoid the game seems too simple, I set up when and only when the game characters jump from below the platform to board the platform and let it have the actual collision volume. In short, when faced with the challenge of crossing a canyon, players can only choose to climb from the edge of the canyon onto the platform and walk through the canyon or jump directly across the canyon. To do this, I need to adjust the function and position of the platform several times, and follow code logic to ensure that the character action and platform function do not conflict, otherwise it will lead to program running errors. Through many revisions, I honed my code reading skills and logical thinking, while also making the games I write more interesting.*/

var gameChar_x;
var gameChar_y;
var floorPos_y;
var scrollPos;
var gameChar_world_x;

var isLeft;
var isRight;
var isFalling;
var isPlummeting;

var clouds;
var mountains;
var trees_x;
var canyon;
var collectable;

var platforms;

var game_score;
var flagpole;
var lives;




var jumpSound;
var backgroundSound;
var collectedSound;
var winSound;
var fallSound;

function preload() {
    soundFormats('mp3', 'wav');

    //load your sounds here
    jumpSound = loadSound('music/jump.wav');
    jumpSound.setVolume(0.1);

    backgroundSound = loadSound('music/BGM.mp3')
    backgroundSound.setVolume(0.1);

    collectedSound = loadSound('music/collectedSound.mp3');
    collectedSound.setVolume(0.1);

    winSound = loadSound('music/winSound.mp3');
    winSound.setVolume(0.1);

    fallSound = loadSound('music/fallSound.mp3');
    fallSound.setVolume(0.1);

}



function setup() {
    createCanvas(1024, 576);
    floorPos_y = height * 3 / 4;

    lives = 3;

    startGame();

}

function startGame() {
    gameChar_x = width / 2;
    gameChar_y = floorPos_y;

    // Variable to control the background scrolling.
    scrollPos = 0;

    // Variable to store the real position of the gameChar in the game
    // world. Needed for collision detection.
    gameChar_world_x = gameChar_x - scrollPos;

    // Boolean variables to control the movement of the game character.
    isLeft = false;
    isRight = false;
    isFalling = false;
    isPlummeting = false;

    // Initialise arrays of scenery objects.
    trees_x = [100, 300, 500, 1000, 1200, 1500, 1900];

    clouds = [{
            x_pos: 0,
            y_pos: 100
    }, {
            x_pos: 500,
            y_pos: 100
    }, {
            x_pos: 900,
            y_pos: 100
    }, {
            x_pos: 1300,
            y_pos: 100
    }, {
            x_pos: 1700,
            y_pos: 100
    }, {
            x_pos: 2000,
            y_pos: 100
    }
];
    mountains = [{
            x_pos: 0,
            width: 100
    }, {
            x_pos: 600,
            width: 100
    }, {
            x_pos: 1100,
            width: 100
    }, {
            x_pos: 1800,
            width: 100
    }, {
            x_pos: -700,
            width: 100
    }, {
            x_pos: -1400,
            width: 100
    }



                ];


    collectable = [{
        x_pos: 100,
        y_pos: 100,
        size: 50,
        isFound: false
    }, {
        x_pos: 450,
        y_pos: 100,
        size: 50,
        isFound: false
    }, {
        x_pos: 900,
        y_pos: 100,
        size: 50,
        isFound: false
    }];

    canyon = [{
        x_pos: 0,
        width: 100
        }, {
        x_pos: 700,
        width: 100
        }, {
        x_pos: 1200,
        width: 100
        }];


    platforms = [];
    platforms.push(createPlatforms(0, floorPos_y - 100, 100));
    platforms.push(createPlatforms(680, floorPos_y - 100, 100));



    game_score = 0;
    flagpole = {
        isReached: false,
        x_pos: 1100
    };

    backgroundSound.play();
}


function draw() {
    background(100, 155, 255); // fill the sky blue

    noStroke();
    fill(0, 155, 0);
    rect(0, floorPos_y, width, height / 4); // draw some green ground

    push();
    translate(scrollPos, 0);
    // Draw clouds.
    drawClouds();

    // Draw mountains.
    drawMountains();

    // Draw trees.
    drawTrees();

    //draw platforms.
    for (var i = 0; i < platforms.length; i++) {
        platforms[i].draw();
    }

    //    Draw canyons;
    for (var i = 0; i < canyon.length; i++) {
        drawCanyon(canyon[i]);
        checkCanyon(canyon[i]);
    };
    // Draw collectable items.
    for (var i = 0; i < collectable.length; i++) {

        if (collectable[i].isFound == false) {
            checkCollectable(collectable[i]);
            drawCollectable(collectable[i]);

        }
    };

    renderFlagpole();

    pop();
    // Draw game character.

    drawGameChar();

    checkPlayerDie();

    fill(255);
    noStroke();
    textSize(20);
    text("score: " + game_score, 20, 20);

    for (i = 0; i < 3; i++) {
        fill(255, 0, 0);
        text("Lives: " + lives, 850, 20);
    }



    //check game over
    if (lives < 1) {
        textSize(40);
        fill(255, 0, 0);
        textAlign(CENTER);
        text("GAME OVER", width / 2, height / 3);
        text("Press space to continue", width / 2, height / 3 + 60);

    }



    //check complete
    if (flagpole.isReached == true) {
        textSize(40);
        fill(255, 255, 0);
        textAlign(CENTER);
        text("LEVEL COMPLETE!", width / 2, height / 3);
        text("Press space to continue", width / 2, height / 3 + 60);
        backgroundSound.pause();
    }


    // Logic to make the game character move or the background scroll.
    if (isLeft) {
        if (gameChar_x > width * 0.2) {
            gameChar_x -= 5;
        } else {
            scrollPos += 5;
        }
    }

    if (isRight) {
        if (gameChar_x < width * 0.8) {
            gameChar_x += 5;
        } else {
            scrollPos -= 5; // negative for moving against the background
        }
    }

    // Logic to make the game character rise and fall.

    if (gameChar_y < floorPos_y) {

        var isContact = false;
        for (var i = 0; i < platforms.length; i++) {
            if (platforms[i].checkContact(gameChar_world_x, gameChar_y) == true) {
                isContact = true;
                break;
            }
        }
        if (isContact == false) {
            gameChar_y += 4;
            isFalling = true;
        }

    } else {
        isFalling = false;
    }

    if (flagpole.isReached == false) {

        checkFlagpole();
    }
    // Update real position of gameChar for collision detection.
    gameChar_world_x = gameChar_x - scrollPos;
}


// ---------------------
// Key control functions
// ---------------------

function keyPressed() {

    //    console.log("press" + keyCode);
    //    console.log("press" + key); 

    if (keyCode == 37) {
        console.log("Left arrow");
        isLeft = true;
    } else if (keyCode == 39) {
        console.log("Right arrow");
        isRight = true;
    }
    if (keyCode == 32 && gameChar_y == floorPos_y) {
        console.log("Space bar");
        if (!isFalling) {
            gameChar_y -= 100;
            jumpSound.play();
        }
    }

    if (keyCode == 32 && lives < 1) {
        location.reload();
        backgroundSound.pause();
        fallSound.play();
    }

    if (keyCode == 32 && flagpole.isReached == true) {
        location.reload();
    }
}

function keyReleased() {

    //    console.log("release" + keyCode);
    //    console.log("release" + key);

    if (keyCode == 37) {
        console.log("Left arrow");
        isLeft = false;
    } else if (keyCode == 39) {
        console.log("Right arrow");
        isRight = false;
    }
    if (keyCode == 32) {
        isFalling = false;
    }
}


// ------------------------------
// Game character render function
// ------------------------------

// Function to draw the game character.

function drawGameChar() {

    // draw game character

    if (isLeft && isFalling) {
        // add your jumping-left code

        fill(0)
        ellipse(gameChar_x - 10, gameChar_y - 60, 20, 20)
        ellipse(gameChar_x - 7, gameChar_y - 40, 10, 40)
        rect(gameChar_x - 3, gameChar_y - 22, 10, 10)
        rect(gameChar_x - 15, gameChar_y - 22, 10, 10)
        ellipse(gameChar_x - 15, gameChar_y - 22, 10, 10)
        fill(255, 255, 255)
        ellipse(gameChar_x - 15, gameChar_y - 60, 5, 5)
        ellipse(gameChar_x - 8, gameChar_y - 60, 5, 5)
    } else if (isRight && isFalling) {
        // add your jumping-right code

        fill(0)
        ellipse(gameChar_x + 10, gameChar_y - 60, 20, 20)
        ellipse(gameChar_x + 7, gameChar_y - 40, 10, 40)
        rect(gameChar_x + 5, gameChar_y - 22, 10, 10)
        rect(gameChar_x - 6, gameChar_y - 22, 10, 10)
        fill(255, 255, 255)
        ellipse(gameChar_x + 8, gameChar_y - 60, 5, 5)
        ellipse(gameChar_x + 16, gameChar_y - 60, 5, 5)


    } else if (isLeft) {
        // add your walking left code

        fill(0)
        ellipse(gameChar_x - 5, gameChar_y - 40, 20, 20)
        ellipse(gameChar_x, gameChar_y - 20, 10, 40)
        rect(gameChar_x - 3, gameChar_y - 5, 10, 10)
        rect(gameChar_x - 15, gameChar_y - 5, 10, 10)
        fill(255, 255, 255)
        ellipse(gameChar_x - 9, gameChar_y - 40, 5, 5)

    } else if (isRight) {
        // add your walking right code

        fill(0)
        ellipse(gameChar_x + 5, gameChar_y - 40, 20, 20)
        ellipse(gameChar_x, gameChar_y - 20, 10, 40)
        rect(gameChar_x + 6, gameChar_y - 5, 10, 10)
        rect(gameChar_x - 6, gameChar_y - 5, 10, 10)
        fill(255, 255, 255)

        ellipse(gameChar_x + 8, gameChar_y - 40, 5, 5)


    } else if (isFalling || isPlummeting) {
        // add your jumping facing forwards code

        fill(0)
        ellipse(gameChar_x, gameChar_y - 60, 20, 20)
        ellipse(gameChar_x, gameChar_y - 40, 10, 40)
        rect(gameChar_x + 3, gameChar_y - 22, 10, 10)
        rect(gameChar_x - 14, gameChar_y - 22, 10, 10)
        fill(255, 255, 255)
        ellipse(gameChar_x - 4, gameChar_y - 60, 5, 5)
        ellipse(gameChar_x + 3, gameChar_y - 60, 5, 5)
    } else {
        // add your standing front facing code

        fill(0)
        ellipse(gameChar_x, gameChar_y - 40, 20, 20)
        ellipse(gameChar_x, gameChar_y - 20, 10, 40)
        rect(gameChar_x + 1, gameChar_y - 5, 10, 10)
        rect(gameChar_x - 12, gameChar_y - 5, 10, 10)
        fill(255, 255, 255)
        ellipse(gameChar_x - 4, gameChar_y - 40, 5, 5)
        ellipse(gameChar_x + 3, gameChar_y - 40, 5, 5)
    }
}

// ---------------------------
// Background render functions
// ---------------------------

// Function to draw cloud objects.
function drawClouds() {
    for (var i = 0; i < clouds.length; i++) {
        fill(255, 0, 127)
        ellipse(clouds[i].x_pos + 50, clouds[i].y_pos, clouds[i].y_pos, clouds[i].y_pos);
        ellipse(clouds[i].x_pos + 100, clouds[i].y_pos, clouds[i].y_pos, clouds[i].y_pos + 10);
        ellipse(clouds[i].x_pos + 150, clouds[i].y_pos, clouds[i].y_pos, clouds[i].y_pos);
        ellipse(clouds[i].x_pos + 200, clouds[i].y_pos, clouds[i].y_pos, clouds[i].y_pos)
    }

}
// Function to draw mountains objects.
function drawMountains() {
    for (var i = 0; i < mountains.length; i++) {
        fill(120, 120, 120)
        triangle(mountains[i].x_pos + 200, mountains[i].width + 333, mountains[i].x_pos + 360, mountains[i].width + 100, mountains[i].x_pos + 550, mountains[i].width + 333)
        fill(255, 255, 255)
        triangle(mountains[i].x_pos + 442, mountains[i].width + 200, mountains[i].x_pos + 292, mountains[i].width + 200, mountains[i].x_pos + 360, mountains[i].width + 100)
    }
}

// Function to draw trees objects.
function drawTrees() {
    for (var i = 0; i < trees_x.length; i++) {
        fill(102, 51, 0)
        rect(trees_x[i] - 170, floorPos_y - 100, 40, 100)

        fill(255, 153, 255)
        ellipse(trees_x[i] - 190, floorPos_y - 110, 50, 50)
        ellipse(trees_x[i] - 110, floorPos_y - 110, 50, 50)
        ellipse(trees_x[i] - 150, floorPos_y - 130, 80, 80)
    }
}

// ---------------------------------
// Canyon render and check functions
// ---------------------------------

// Function to draw canyon objects.

function drawCanyon(t_canyon) {
    fill(110, 155, 255)
    rect(t_canyon.x_pos + 10, t_canyon.width + 332, t_canyon.width - 42, t_canyon.width + 30)
    fill(139, 69, 19)
    rect(t_canyon.x_pos + 10, t_canyon.width + 430, t_canyon.width - 40, t_canyon.width - 50)
    rect(t_canyon.x_pos + 5, t_canyon.width + 333, t_canyon.width - 95, t_canyon.width + 50)
    rect(t_canyon.x_pos + 67, t_canyon.width + 333, t_canyon.width - 95, t_canyon.width + 50)
}


// Function to check character is over a canyon.
function checkCanyon(t_canyon) {
    if ((gameChar_world_x >= t_canyon.x_pos + 15 && gameChar_world_x <= (t_canyon.x_pos + 65)) && gameChar_y == floorPos_y) {
        isPlummeting = true;
        gameChar_y += 250;
    }
}



// ----------------------------------
// Collectable items render and check functions
// ----------------------------------

// Function to draw collectable objects.

function drawCollectable(t_collectable) {
    fill(102, 51, 0)
    rect(t_collectable.x_pos + 100, t_collectable.y_pos + 283, t_collectable.size + 50, t_collectable.size)

    fill(0, 0, 0)
    ellipse(t_collectable.x_pos + 153, t_collectable.y_pos + 300, t_collectable.size - 35, t_collectable.size - 35)
    rect(t_collectable.x_pos + 100, t_collectable.y_pos + 300, t_collectable.size - 5, t_collectable.size - 48)
    rect(t_collectable.x_pos + 160, t_collectable.y_pos + 300, t_collectable.size - 10, t_collectable.size - 48)

}

// Function to check character has collected an item.

function checkCollectable(t_collectable) {
    if (abs(
            (t_collectable.x_pos + 150) - gameChar_world_x) < 50) {
        t_collectable.isFound = true;
        game_score += 1;
        collectedSound.play();
    }
};


function renderFlagpole() {
    push();
    strokeWeight(5);
    stroke(180);
    line(flagpole.x_pos, floorPos_y, flagpole.x_pos, floorPos_y - 250);
    fill(255, 0, 255);
    noStroke();

    if (flagpole.isReached) {
        rect(flagpole.x_pos, floorPos_y - 250, 50, 50);
    } else {
        rect(flagpole.x_pos, floorPos_y - 50, 50, 50);
    }
    pop();

}

function checkFlagpole() {
    var d = abs(gameChar_world_x - flagpole.x_pos);


    if (d < 20) {
        flagpole.isReached = true;
        winSound.play();
    }

}


function checkPlayerDie() {
    if (gameChar_y >= floorPos_y + 50 && (lives > 0)) {
        lives -= 1;
        fallSound.play();
        if (lives > 0) {
            startGame();
            backgroundSound.pause();
        }
    }
}

function createPlatforms(x, y, length) {
    var p = {
        x: x,
        y: y,
        length: length,
        draw: function () {
            fill(255, 0, 255);
            rect(this.x, this.y, this.length + 10, 20);

        },

        checkContact: function (gc_x, gc_y) {
            if ((gc_x >= this.x - 10 && gc_x <= this.x + this.length + 10)) {
                var d = this.y - gc_y;
                if (d >= 0 && d < 5) {
                    return true;
                }
            }

            return false;
        }
    }
    return p;
}
