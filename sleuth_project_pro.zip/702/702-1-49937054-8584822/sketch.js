/*

Officer: 8584822
CaseNum: 702-1-49937054-8584822

Case 702 - The case of Vanishing Vannevar
Stage 2 - Downtown traffic

“All units: Vannevar is heading into the downtown area. Heavy traffic ahead. Drive safely.”
Complete the helper functions below to drive the car and avoid other vehicles. Keep on it kid.

There are many possible ways of completing this task,
but you should ONLY use the following commands and techniques:

	- Incrementing and assiging variables
	- Maths function such as random and constrain
	- Conditional statements
	- Traversing arrays with for loops
	- calling functions and returning values

HINT: make sure you take a look at the initialisation of Sleuth_VehicleObject and the cars in
vehicleObjects_array to understand their properties.

*/

///////////////////////// HELPER FUNCTIONS /////////////////////

function drive_car() {
    /*
    This function should do the following: 
     - increment Sleuth_VehicleObject's Distance_Amount property by its Speed_Value property 
     - add a random amount between -0.05 and 0.05 to Sleuth_VehicleObject's EngineRumble_Amount property
     - use the constrain function to constrain Sleuth_VehicleObject's EngineRumble_Amount property to values between 0.1 and 1.2
     - call the run_carEngine function passing Sleuth_VehicleObject as an argument
    */
    Sleuth_VehicleObject.Distance_Amount += Sleuth_VehicleObject.Speed_Value;
    Sleuth_VehicleObject.EngineRumble_Amount += random(-0.05, 0.05);
    Sleuth_VehicleObject.EngineRumble_Amount = constrain(Sleuth_VehicleObject.EngineRumble_Amount, 0.1, 1.2);
    run_carEngine(Sleuth_VehicleObject);
}


function cross_lanes(carObj) {
    /*
    This
    function should do the following:
        -move carObj from one lane to the other. -
        do the move in a single step without any extra animation. -
            use lane_coord_a and lane_coord_b to effect the change. -
            finally you should
        return carObj at the end of the
        function.
        hint: You will need to modify the Coord_X property of carObj.*/
    







}


function search_isAhead(carObj) {
    /*
    This function should do the following: 
     - determine if carObj is in the same lane and less than 200px behind any of the cars in vehicleObjects_array.
     - do this by traversing vehicleObjects_array and comparing each car's Distance_Amount property to that of carObj.
     - if you find a car that matches these requirements then return the Licence_Plate property for the car. Otherwise return false.
    */
}


//////////////DO NOT CHANGE CODE BELOW THIS LINE//////////////////

var Sleuth_VehicleObject;

var roadWidth;
var roadLeftEdge;
var lane_coord_a;
var lane_coord_b;
var carImages = {};

var vehicleObjects_array = [
    {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: -200,
        Car_Category: 'blueCar',
        Licence_Plate: '81O8A1',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 200,
        Car_Category: 'whiteCar',
        Licence_Plate: '33D8J4',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 600,
        Car_Category: 'greenCar',
        Licence_Plate: 'RDWE4N',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 1000,
        Car_Category: 'blueCar',
        Licence_Plate: 'Z08THS',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 1400,
        Car_Category: 'whiteCar',
        Licence_Plate: '1B395P',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 500,
        Coord_Y: 0,
        Distance_Amount: 1800,
        Car_Category: 'blueCar',
        Licence_Plate: '4EQOSX',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 2200,
        Car_Category: 'greenCar',
        Licence_Plate: '2Q9B2U',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 2600,
        Car_Category: 'blueCar',
        Licence_Plate: 'P0TVTD',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 500,
        Coord_Y: 0,
        Distance_Amount: 3000,
        Car_Category: 'whiteCar',
        Licence_Plate: 'FPSMVS',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 3400,
        Car_Category: 'whiteCar',
        Licence_Plate: '2WJ9FX',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 3800,
        Car_Category: 'greenCar',
        Licence_Plate: 'HAMVRE',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 500,
        Coord_Y: 0,
        Distance_Amount: 4200,
        Car_Category: 'greenCar',
        Licence_Plate: '0J3BF5',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 500,
        Coord_Y: 0,
        Distance_Amount: 4600,
        Car_Category: 'redCar',
        Licence_Plate: 'WBG3WF',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 500,
        Coord_Y: 0,
        Distance_Amount: 5000,
        Car_Category: 'blueCar',
        Licence_Plate: 'KYWEGE',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 5400,
        Car_Category: 'blueCar',
        Licence_Plate: 'WNO1HY',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 500,
        Coord_Y: 0,
        Distance_Amount: 5800,
        Car_Category: 'blueCar',
        Licence_Plate: 'GDV4JG',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 6200,
        Car_Category: 'blueCar',
        Licence_Plate: 'KM9MVS',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 500,
        Coord_Y: 0,
        Distance_Amount: 6600,
        Car_Category: 'redCar',
        Licence_Plate: 'PFU95T',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 500,
        Coord_Y: 0,
        Distance_Amount: 7000,
        Car_Category: 'greenCar',
        Licence_Plate: 'I6GNQK',
        Speed_Value: 2,
        exhaust: []
    }, {
        Coord_X: 300,
        Coord_Y: 0,
        Distance_Amount: 7400,
        Car_Category: 'greenCar',
        Licence_Plate: 'XLGOJA',
        Speed_Value: 2,
        exhaust: []
    }
];



function preload() {
    var carTypes = [
		"detective",
		"redCar",
		"greenCar",
		"blueCar",
		"whiteCar",
	];

    for (var i = 0; i < carTypes.length; i++) {
        carImages[carTypes[i]] = loadImage("cars/" + carTypes[i] + ".png");
    }
}

function setup() {
    createCanvas(800, 800);

    roadWidth = 400;
    roadLeftEdge = 200;
    lane_coord_a = 300;
    lane_coord_b = 500;

    Sleuth_VehicleObject = {
        Coord_X: roadLeftEdge + roadWidth / 4,
        Coord_Y: 550,
        Distance_Amount: 0,
        Speed_Value: 3,
        EngineRumble_Amount: 0,
        Car_Category: 'detective',
        Licence_Plate: '5L3UTH',
        exhaust: []
    }


}



function draw() {
    background(0);



    drawRoad();
    drawCars();

    ////////////////////// HANDLE DETECTIVE /////////////////////////


    drive_car();
    var b2b = search_isAhead(Sleuth_VehicleObject);
    if (b2b) cross_lanes(Sleuth_VehicleObject);


    //////////////////////HANDLE THE OTHER CARS//////////////////////

    for (var i = 0; i < vehicleObjects_array.length; i++) {
        vehicleObjects_array[i].Distance_Amount += vehicleObjects_array[i].Speed_Value;
        vehicleObjects_array[i].Coord_Y = Sleuth_VehicleObject.Coord_Y - vehicleObjects_array[i].Distance_Amount + Sleuth_VehicleObject.Distance_Amount;
    }

}

/////////////////////////DRAWING FUNCTIONS////////////////////////

function drawRoad() {
    stroke(100);
    fill(50);
    rect(roadLeftEdge, 0, roadWidth, 800);
    stroke(255);

    for (var i = -1; i < 20; i++) {
        line(
            roadLeftEdge + roadWidth / 2, i * 100 + (Sleuth_VehicleObject.Distance_Amount % 100),
            roadLeftEdge + roadWidth / 2, i * 100 + 70 + (Sleuth_VehicleObject.Distance_Amount % 100)
        );
    }
}

function drawCars() {
    //draw the detective car

    image
    drawExhaust(Sleuth_VehicleObject);
    image
        (
            carImages["detective"],
            Sleuth_VehicleObject.Coord_X - carImages["detective"].width / 2 + random(-Sleuth_VehicleObject.EngineRumble_Amount, Sleuth_VehicleObject.EngineRumble_Amount),
            Sleuth_VehicleObject.Coord_Y + random(-Sleuth_VehicleObject.EngineRumble_Amount, Sleuth_VehicleObject.EngineRumble_Amount)
        );

    //draw all other cars

    for (var i = 0; i < vehicleObjects_array.length; i++) {
        if (vehicleObjects_array[i].Coord_Y < height && vehicleObjects_array[i].Coord_Y > -height / 2) {
            image(
                carImages[vehicleObjects_array[i].Car_Category],
                vehicleObjects_array[i].Coord_X - carImages[vehicleObjects_array[i].Car_Category].width / 2,
                vehicleObjects_array[i].Coord_Y
            );
            run_carEngine(vehicleObjects_array[i]);

            drawExhaust(vehicleObjects_array[i]);
        }
    }

}

function run_carEngine(car) {

    car.exhaust.push({
        size: 2,
        x: car.Coord_X,
        y: car.Coord_Y + carImages[car.Car_Category].height
    });

    for (var i = car.exhaust.length - 1; i >= 0; i--) {

        car.exhaust[i].y += max(0.75, car.Speed_Value / 3);
        if (car.Car_Category != "detective") car.exhaust[i].y += (Sleuth_VehicleObject.Speed_Value - car.Speed_Value);
        car.exhaust[i].x += random(-1, 1);
        car.exhaust[i].size += 0.5;

        if (car.exhaust[i].y > height || car.exhaust[i].y < 0) {
            car.exhaust.splice(i, 1);
        }
    }
}


function drawExhaust(car) {
    noStroke();
    for (var i = 0; i < car.exhaust.length; i++) {
        var alpha = map(car.exhaust[i].size, 0, 40, 50, 0);
        fill(125, alpha);
        ellipse(car.exhaust[i].x + 20, car.exhaust[i].y, car.exhaust[i].size);

    }
}
