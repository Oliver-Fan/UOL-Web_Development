/*
Officer: 8584822
CaseNum: 601-2-50158847-8584822

Case 601 - Murdering Again - stage 3

Now murders are beginning to occur - we're pretty sure that this is the work of Fry.
If we can place her near any of the recent crime scenes in the area we should be able narrow down her location.

In the setup function, use a for loop to traverse the sightings, marking all of the locations on the map
where she was last seen. Do this by drawing small, DarkViolet fill ellipses at each location.

In addition, we've assembled a list of recent thefts in the area. Using another for loop to traverse the
recent crime records, you should mark those locations on the map. Do this by drawing small, Chocolate stroke triangles centered over each location.

Use X11 colours. You can find a reference table at https://en.wikipedia.org/wiki/Web_colors.

Let 's try to catch Fry by looking patterns between sightings and crimes. If she was within less than 98 pixels of any of the crimes then the details
should be pushed to possible matches with the following format.

{ suspect_x: 0, suspect_y: 0 ,crime_x: 0, crime_y: 0, victimName: "John_Doe" }

Note that the possible matches are already being drawn.
Your job is simply to fill the array with the correct data.

For this mission you will need ONLY the following:

- for loop
- dist()
- if()
- fill
- ellipse()

- stroke
- triangle() NB. Draw each triangle with the point roughly at its center.


*/

var countyMap;

var possibleMatches = [];

//Sightings of Casey Fry.

var Murderer_Record = [
    {
        LocationX: 639,
        LocationY: 288
    },
    {
        LocationX: 681,
        LocationY: 286
    },
    {
        LocationX: 712,
        LocationY: 293
    },
    {
        LocationX: 756,
        LocationY: 310
    },
    {
        LocationX: 715,
        LocationY: 368
    },
    {
        LocationX: 701,
        LocationY: 425
    },
    {
        LocationX: 753,
        LocationY: 436
    },
    {
        LocationX: 815,
        LocationY: 468
    },
    {
        LocationX: 795,
        LocationY: 506
    },
    {
        LocationX: 788,
        LocationY: 497
    },
    {
        LocationX: 781,
        LocationY: 486
    },
    {
        LocationX: 768,
        LocationY: 489
    },
    {
        LocationX: 750,
        LocationY: 500
    },
    {
        LocationX: 732,
        LocationY: 506
    },
    {
        LocationX: 714,
        LocationY: 514
    },
    {
        LocationX: 695,
        LocationY: 531
    },
    {
        LocationX: 693,
        LocationY: 552
    },
    {
        LocationX: 654,
        LocationY: 523
    },
    {
        LocationX: 624,
        LocationY: 500
    },
    {
        LocationX: 594,
        LocationY: 484
    },
    {
        LocationX: 555,
        LocationY: 474
    }
];


//Recent crime records.

var Killing_Record = [
    {
        PointX: 409,
        PointY: 446,
        VictimDetails: 'PIERRE DORCEY'
    },
    {
        PointX: 443,
        PointY: 419,
        VictimDetails: 'LAVERNE JACQUELIN'
    },
    {
        PointX: 465,
        PointY: 548,
        VictimDetails: 'DEEDEE PHINNEY'
    },
    {
        PointX: 709,
        PointY: 552,
        VictimDetails: 'TU DAVISWOOD'
    },
    {
        PointX: 695,
        PointY: 421,
        VictimDetails: 'SUMMER CASIMERE'
    },
    {
        PointX: 652,
        PointY: 268,
        VictimDetails: 'JESSIA PORTOS'
    },
    {
        PointX: 641,
        PointY: 306,
        VictimDetails: 'DRUSILLA WARMAN'
    },
    {
        PointX: 119,
        PointY: 344,
        VictimDetails: 'HANG NIEMELA'
    },
    {
        PointX: 114,
        PointY: 359,
        VictimDetails: 'LAKESHA SYMMES'
    },
    {
        PointX: 90,
        PointY: 490,
        VictimDetails: 'MAJORIE JENI'
    },
    {
        PointX: 76,
        PointY: 516,
        VictimDetails: 'KITTY THAXTER'
    },
    {
        PointX: 615,
        PointY: 741,
        VictimDetails: 'JULIANA ADVERSANE'
    },
    {
        PointX: 349,
        PointY: 796,
        VictimDetails: 'LINETTE MOHWAWK'
    },
    {
        PointX: 456,
        PointY: 770,
        VictimDetails: 'TAMICA MAUBERT'
    }
];


function preload() {
    countyMap = loadImage("map.png")
}

function setup() {
    createCanvas(countyMap.width, countyMap.height);

    image(countyMap, 0, 0);

    //add your code below here
    for (var i = 0; i < possibleMatches.length; i++) {
        noStroke();
        fill(148, 0, 211);
        ellipse(possibleMatches[i].Murderer_Record.LocationX, possibleMatches[i].Murderer_Record.LocationY, 5, 5);


        noFill();
        stroke(210, 105, 30);
        triangle(possibleMatches[i].Killing_Record.PointX - 5, possibleMatches[i].Killing_Record.PointY - 5, possibleMatches[i].Killing_Record.PointX + 5, possibleMatches[i].Killing_Record.PointY - 5, possibleMatches[i].Killing_Record.PointX, possibleMatches[i].Killing_Record.PointY + 5);

        //    if (dist(Murderer_Record[i].LocationX, Murderer_Record[i].LocationY, Killing_Record[j].PointX, Killing_Record[j].PointY) <= 98) {
        //        possibleMatches.push({
        //            suspect_x: Murderer_Record[i].LocationX,
        //            suspect_y: Murderer_Record[i].LocationY,
        //            crime_x: Killing_Record[j].PointX,
        //            crime_y: Killing_Record[j].PointY,
        //            victimName: Killing_Record[j].VictimDetails
    }


    //     code to draw the matches ( if any)
    for (let i = 0; i < possibleMatches.length; i++) {
        stroke(127);
        strokeWeight(3);
        line(possibleMatches[i].crime_x, possibleMatches[i].crime_y, possibleMatches[i].suspect_x, possibleMatches[i].suspect_y);

        noStroke();
        fill(127);
        text(possibleMatches[i].victimName, possibleMatches[i].crime_x + 15, possibleMatches[i].crime_y + 15);
    }
}

//We are not using the draw function this time
